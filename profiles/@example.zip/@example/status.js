function user_status(){
  /*Edit below line to update your profile's status*/
  document.getElementById("profileStatus").innerHTML = 'A test of the mobile editing'

}
